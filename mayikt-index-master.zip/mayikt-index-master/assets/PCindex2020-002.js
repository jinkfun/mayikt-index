

$(function() {
    //头部广告
    $('.titleImg-del').click(function () {
        $('.titleImg').hide()
    })
    // 轮播图
    jQuery(".slideBox").slide({
        mainCell: ".bd ul",
        autoPlay: true,
        effect: "fold",
        startFun: function(i) {
            $('section').removeClass('section0 section1 section2 section3 section4').addClass('section'+i+'')
        }
    });

    // 侧边栏菜单
    $(".nav-list").find('li').hover(function() {
        var nav_index = $(this).index()
        $('.mayi').hide();
        $('.mayi').eq(nav_index).show();
    }, function() {
        $('.mayi').hide();
    })

    $('.mayi').hover(function() {
        $('.mayi').hide()
        $(this).show();
    }, function() {
        $('.mayi').hide()
    })
    // 学生信息展示
    // var swiper = new Swiper('.swiper-container-fade', {
    // 	spaceBetween: 30,
    // 	autoplay: true,
    // 	effect: 'fade',
    // 	loop: true,
    // 	pagination: {
    // 		el: '.swiper-pagination',
    // 		clickable: true,
    // 	},
    // 	navigation: {
    // 		nextEl: '.swiper-button-next',
    // 		prevEl: '.swiper-button-prev',
    // 	},
    // });
    //fixed帮助中心
    $('#help-centre').hover(function() {
        $(this).html('帮助<br>中心')
    }, function() {
        $(this).html('<img src="static/imgages/index-img/icon1@2x(1).png" />')
    })
    $('#fankui').hover(function() {
        $(this).html('一键<br>反馈')
    }, function() {
        $(this).html('<img src="static/imgages/index-img/icon2@2x(1).png" />')
    })
    $('#help-my-app').hover(function() {
        $(this).html('蚂蚁<br>APP')
    }, function() {
        $(this).html('<img src="static/imgages/index-img/icon3@2x(1).png" />')
    })
    $('#help-chengxu').hover(function() {
        $(this).html('蚂蚁<br>小程序')
    }, function() {
        $(this).html('<img src="static/imgages/index-img/icon4@2x(1).png" />')
    })
    // $('#help-weixin').hover(function() {
    //     $(this).html('微信<br>公众号')
    //     $('.weixin').animate({
    //         height: "181px",
    //         width: "149px",
    //         "opacity": "1"
    //     });

    // }, function() {
    //     $(this).html('<img src="static/imgages/index-img/icon5@2x(1).png" />')
    //     $('.weixin').css({
    //         height: "0",
    //         width: "0"
    //     });
    // })
    // $('.weixin').hover(function() {
    //     $('.weixin').css({
    //         height: "181px",
    //         width: "149px"
    //     })
    // }, function() {
    //     $('.weixin').css({
    //         height: "0",
    //         width: "0"
    //     });
    // })
    $('#help-top').hover(function() {
        $(this).html('一键<br>向上')
    }, function() {
        $(this).html('<img src="static/imgages/index-img/icon6@2x(1).png" />')
    })

    var scrollTop = document.documentElement.scrollTop || document.body.scrollTop;
    $('#help-top').click(function() {
        $('body,html').animate({
            scrollTop: 0
        }, 300)
    })
    // 学生评价
    var certifySwiper = new Swiper('#certify .swiper-container-student', {
        watchSlidesProgress: true,
        spaceBetween: -220,
        slidesPerView: 'auto',
        centeredSlides: true,
        loop: true,
        loopedSlides: 5,
        autoplay: {
            delay: 2500,
            disableOnInteraction: false,
        },
        navigation: {
            nextEl: '.student-left-btn',
            prevEl: '.student-right-btn',
        },
        pagination: {
            el: '.swiper-pagination',
            //clickable :true,
        },
        on: {
            progress: function(progress) {
                for (i = 0; i < this.slides.length; i++) {
                    var slide = this.slides.eq(i);
                    var slideProgress = this.slides[i].progress;
                    modify = 1;
                    if (Math.abs(slideProgress) > 1) {
                        modify = (Math.abs(slideProgress) - 1) * 0.3 + 1;
                    }
                    translate = slideProgress * modify * 260 + 'px';
                    scale = 1 - Math.abs(slideProgress) / 5;
                    zIndex = 999 - Math.abs(Math.round(10 * slideProgress));
                    slide.transform('translateX(' + translate + ') scale(' + scale + ')');
                    slide.css('zIndex', zIndex);
                    slide.css('opacity', 1);
                    if (Math.abs(slideProgress) > 3) {
                        slide.css('opacity', 0);
                    }
                }
            },
            setTransition: function(transition) {
                for (var i = 0; i < this.slides.length; i++) {
                    var slide = this.slides.eq(i)
                    slide.transition(transition);
                }
            }
        }
    })
    // 鼠标移入停止播放，移除继续自动播放
    $('#certify .swiper-container-student').hover(function(){
        certifySwiper.autoplay.stop()
    },function(){
        certifySwiper.autoplay.start()
    })


    // 数字自加
    var student1timer = null;
    var count1 = 0;
    var onlyone = false;
    var t_height = $(".studentback").offset().top - $(document).scrollTop();
    $(window).scroll(function() {

        if ($(window).scrollTop() == $(document).height() - $(window).height()) {
            countM1()
            countM2()
            countM3()
        }
    });

    function countM1() {
        student1timer = setInterval(function() {
            count1 = count1 + parseInt(Math.random(0, 1) * 60);

            if (count1 > 10000) {
                clearInterval(student1timer);
                count1 = 10000
            }
            $('.student-count1').html(count1 + "+")
        }, 5)
    }
    var student2timer = null;
    var count2 = 0;

    function countM2() {
        student2timer = setInterval(function() {
            count2 = count2 + parseInt(Math.random(0, 1) * 1200);

            if (count2 > 195000) {
                clearInterval(student2timer);
                count2 = 195000
            }
            $('.student-count2').html(count2 + "+")
        }, 5)
    }
    var student3timer = null;
    var count3 = 0;

    function countM3() {
        student3timer = setInterval(function() {
            count3 = count3 + parseInt(Math.random(0, 1) * 30);

            if (count3 > 5000) {
                clearInterval(student3timer);
                count3 = 5000
            }
            $('.student-count3').html(count3 + "+")
        }, 5)
    }

    // 老师风采展示列表
    var swiper = new Swiper('.teacher-show', {
        autoplay: {
            delay: 2500,
            disableOnInteraction: false,
        },
        slidesPerView: 3,
        spaceBetween: 30,
        slidesPerGroup: 1,
        loop: true,
        loopFillGroupWithBlank: true,
        autoplayDisableOnInteraction: false,
        pagination: {
            el: '.swiper-pagination',
            clickable: true,
        },
        navigation: {
            nextEl: '.teacher-left',
            prevEl: '.teacher-right',
        },
    });
    // 鼠标移入停止播放，移除继续自动播放
    $('.teacher-show').hover(function(){
        swiper.autoplay.stop()
    },function(){
        swiper.autoplay.start()
    })

    // 注册登录切换````````````````````````````````````````````````````````````````````````````````````
    // 点击登录

    function load() {
        $('.header-load-concent').find('h1').removeClass('change change2')
        $('.header-load-concent').find('h1').find('span').removeClass('change-color')
        $('.motaiceng').show();
        $('.header-load-concent').show();
        $('.header-loading').show();
        $('.header-zhuce').hide();
        $('.header-load-concent').find('h1').addClass('change2')
        $('.header-load-concent').find('h1').find('.load-span').addClass('change-color')
    }
    /**
    // 点击注册```````````````````````````````````````````````````````````````````````````````````````
    $('#btn-zhuce').click(function() {
        register()
        unScroll();
    })
    $('.zhuce-span').click(function() {
        register()
        unScroll();
    })
    **/


    function register() {
        $('.header-load-concent').find('h1').removeClass('change change2')
        $('.header-load-concent').find('h1').find('span').removeClass('change-color')
        $('.motaiceng').show();
        $('.header-load-concent').show();
        $('.header-loading').hide();
        $('.header-zhuce').show();
        $('.header-load-concent').find('h1').addClass('change')
        $('.header-load-concent').find('h1').find('.zhuce-span').addClass('change-color')
    }
    //点击关闭登录界面
    $('.load-del').click(function() {
        $('.motaiceng').hide();
        $(".ddd").hide()
        $('.header-load-concent').hide();
        $('.header-find-possword').addClass('header-find-possword')
        $('.clear-empty').each(function(){
            $(this).val(this.defaultValue).css('color','#999')

        })
        removeUnScroll();
    })

    $('.motaiceng').click(function() {
        $('.motaiceng').hide();
        $(".ddd").hide()
        $('.header-load-concent').hide();
        removeUnScroll();
    })
    // 滚动条禁止滚动
    function unScroll() {
        var top = $(document).scrollTop();
        $(document).on('scroll.unable', function(e) {
            $(document).scrollTop(top);
        })
    }
    // 允许滚动
    function removeUnScroll() {
        $(document).unbind("scroll.unable");
    }

    //  账号框和密码获得失去焦点
    $(".inp-load").focus(function cls() {
        //捕获触发事件的对象，并设置为以下语句的默认对象
        with(event.srcElement)
            //如果当前值为默认值，则清空
            if (value == defaultValue) {
                value = ""
            }
        $(this).css("color", "#333")
        $(this).parent().css("border-color", "rgba(223, 50, 37, 1)")
    });

    $(".inp-load").blur(function cls() {

        //捕获触发事件的对象，并设置为以下语句的默认对象
        with(event.srcElement)
            //如果当前值为默认值，则清空
            if (value == "") {
                value = defaultValue
                $(this).css("color", "rgba(153, 153, 153, 1)")
            }
        $(this).parent().css("border-color", "rgba(228, 228, 228, 1)")
    });
    // 输入账号框 失去焦点时,清空value内容,判断输入格式是否正确
    $(".inp-load1").focus(function() {
        $(this).parent().addClass('header-loading-input11')
    })
    $(".inp-load1").blur(function res() {
        $(this).parent().removeClass('header-loading-input11')
        var val = $(this).val();
        var reg = new RegExp("^([0-9A-Za-z\\-_\\.]+)@([0-9a-z]+\\.[a-z]{2,3}(\\.[a-z]{2})?)$");
        var myreg = /^[1][3,4,5,7,8][0-9]{9}$/;
        if (val == "") { //输入不能为空
            // $('.right-phone-num').css("visibility", "hidden")
        } else if (reg.test(val)) {
            $('.right-phone-num').css("visibility", "hidden")
        } else if (myreg.test(val)) {
            $('.right-phone-num').css("visibility", "hidden")
        } else {
            $('.right-phone-num').css("visibility", "visible")
        }
    });

    //输入密码框失去焦点时
    $(".inp-load2").focus(function() {
        $(this).parent().addClass('header-loading-input22')
    })
    $(".inp-load2").blur(function res() {
        $(this).parent().removeClass('header-loading-input22')
        var val = $(this).val();
        var reg = /[\s\S]{6,}/;
        var flag = reg.test(val);
        if (flag == false) {
            $('.num-possword').css("visibility", "visible")
            // return false;
        } else {
            $('.num-possword').css("visibility", "hidden")
        }
    });

    // 注册部分------------------------------------------------------------------
    $(".zhuce-public").focus(function cls() {

        $('.zhuce-ma').css("display", "block")
        //捕获触发事件的对象，并设置为以下语句的默认对象
        with(event.srcElement)
            //如果当前值为默认值，则清空
            if (value == defaultValue) {
                value = ""
            }
        $(this).css("color", "#333")
        $(this).parent().css("border-color", "rgba(223, 50, 37, 1)")
    });
    //注册失去焦点时
    $(".zhuce-public").blur(function cls() {
        //捕获触发事件的对象，并设置为以下语句的默认对象
        with(event.srcElement)
            //如果当前值为空，则重置为默认值
            if (value == "") {
                value = defaultValue
                $(this).css("color", "rgba(153, 153, 153, 1)")
            }
        $(this).parent().css("border-color", "rgba(228, 228, 228, 1)")
    });

    $('.header-loading-input').find("input").focus(function() {
        var index = $(this).index()
    })


    // 输入邮箱判断
    $(".zhece-email").focus(function() {
        $(this).parent().addClass('header-zhuce-input11')
    })
    $(".zhece-email").blur(function res() {
        $(this).parent().removeClass('header-zhuce-input11')
        var val = $(this).val();
        var reg = /^\w{3,}(\.\w+)*@[A-z0-9]+(\.[A-z]{2,5}){1,2}$/;
        var flag = reg.test(val);
        if (flag == false) {
            $('.right-email').css("visibility", "visible")
            // return false;
        } else {
            $('.right-email').css("visibility", "hidden")
        }
    });
    // 输入手机号码判断
    $(".zhece-phone").focus(function() {
        $(this).parent().addClass('header-zhuce-input22')
    })
    $(".zhece-phone").blur(function res() {
        $(this).parent().removeClass('header-zhuce-input22')
        var val = $(this).val();
        var reg = /^[1][3,4,5,7,8][0-9]{9}$/;
        var flag = reg.test(val);
        if (flag == false) {
            $('.right-phone').css("visibility", "hidden")
            // return false;
        } else {
            $('.right-phone').css("visibility", "hidden")
        }
    });
    // 输入注册判断
    $(".zhece-id").focus(function() {
        $(this).parent().addClass('header-zhuce-input33')
    })
    $(".zhece-id").blur(function res() {
        $(this).parent().removeClass('header-zhuce-input33')
        // 后台判断二维码
    });

    // 输入密码判断
    $(".zhece-password").focus(function() {
        $(this).parent().addClass('header-zhuce-input44')
    })
    $(".zhece-password").blur(function res() {
        $(this).parent().removeClass('header-zhuce-input44')
        var val = $(this).val();
        var reg = /^.{6,}$/;
        var flag = reg.test(val);
        if (flag == false) {
            $('.right-possword').css("visibility", "visible")
            // return false;
        } else {
            $('.right-possword').css("visibility", "hidden")
        }
    });
    //输入第二次密码判断是否一致
    $(".zhece-password-r").focus(function() {
        $(this).parent().addClass('header-zhuce-input55')
    })
    $(".zhece-password-r").blur(function res() {
        $(this).parent().removeClass('header-zhuce-input55')
        var val = $(this).val();
        var val1 = $('.zhece-password').val();
        if (val != val1) {
            $('.right-same').css("visibility", "visible")
            // return false;
        } else {
            $('.right-same').css("visibility", "hidden")
        }
    });

    //  后台判断验证码输入验证码判断


    // 找回密码--------------------------------------------------------------
    $(".find-p").focus(function cls() {
        //捕获触发事件的对象，并设置为以下语句的默认对象
        with(event.srcElement)
            //如果当前值为默认值，则清空
            if (value == defaultValue) {
                value = ""
            }
        $(this).css("color", "#333")
        $(this).parent().css("border-color", "rgba(223, 50, 37, 1)")
        $(this).parent().addClass('.send-msg33')
    });
    //找回密码失去焦点时
    $(".find-p").blur(function cls() {
        //捕获触发事件的对象，并设置为以下语句的默认对象
        with(event.srcElement)
            //如果当前值为空，则重置为默认值
            if (value == "") {
                value = defaultValue
                $(this).css("color", "rgba(153, 153, 153, 1)")
            }
        $(this).parent().css("border-color", "rgba(228, 228, 228, 1)")
        $(this).parent().removeClass('.send-msg33')
    });
    // 发行短信倒计时
    var countdown = 60;/*
	$('#send-btn').click(function() {
		sendemail()
	})*/

    function sendemail() {
        var obj = $("#send-btn");
        settime(obj);
    }

    function settime(obj) { //发送验证码倒计时
        if (countdown == 0) {
            obj.attr('disabled', false);
            //obj.removeattr("disabled");
            obj.html("发送短信");
            countdown = 60;
            return;
        } else {
            obj.attr('disabled', true);
            obj.html("重新发送(" + countdown + ")");
            countdown--;
        }
        setTimeout(function() {
            settime(obj)
        }, 1000)
    }

    // 输入密码切换
    $('#forget-possword').click(function() {
        $('.header-load-concent-1').hide()
        $(".ddd").show()
    })
})
